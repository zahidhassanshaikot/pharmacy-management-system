<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<h3>Hello {{ $name }}</h3><br><br>
<p>Welcome to our Company. Now you are {{$role}} in our system....</p>
<br><br>
<br>

</body>
</html>
