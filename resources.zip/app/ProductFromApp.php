<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductFromApp extends Model
{
    protected $table='product_from_app';
}
