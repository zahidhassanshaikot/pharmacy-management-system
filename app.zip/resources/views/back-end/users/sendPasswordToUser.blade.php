<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<h3>Hello {{ $name }}</h3><br><br>
<p>Welcome to our news portal. Your password is : {{ $randPassword }} <br>You can sign in with this password. </p>
<br><br>
<br>

</body>
</html>
